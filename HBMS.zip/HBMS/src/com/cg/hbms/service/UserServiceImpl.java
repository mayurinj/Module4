package com.cg.hbms.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.hbms.dao.UserDao;
import com.cg.hbms.dao.UserDaoImpl;
import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Users;
import com.cg.hbms.dto.roomDetails;
import com.cg.hbms.exception.HotelException;

public class UserServiceImpl implements UserService{

	UserDao userDao;
	public UserServiceImpl() throws HotelException
	{
		userDao = new UserDaoImpl();
	}
	@Override
	public int bookRoom(BookingDetails bookingDetails) throws HotelException {
		// TODO Auto-generated method stub
		return userDao.bookRoom(bookingDetails);
	}
	@Override
	public ArrayList<BookingDetails> viewBookingStatus(String userId) throws HotelException {
		// TODO Auto-generated method stub
		return userDao.viewBookingStatus(userId);
	}
	@Override
	public int addUser(Users user) throws HotelException {
		// TODO Auto-generated method stub
		return userDao.addUser(user);
	}
	@Override
	public String login(String userId, String password) throws HotelException{
		// TODO Auto-generated method stub
		
		return userDao.login(userId, password);
	}
	@Override
	public ArrayList<roomDetails> searchRoom(String hotel_id) throws HotelException{
		// TODO Auto-generated method stub
		return userDao.searchRoom(hotel_id);
	}
	@Override
	public boolean validate_userName(String username) throws HotelException {
		// TODO Auto-generated method stub
		ArrayList<String> userNames = userDao.getListofUsername();
		if(username.length()>4)
			return false;
		if(userNames.contains(username))
			return false;
		return true;
	}
	@Override
	public boolean validate_password(String password) throws HotelException {
		// TODO Auto-generated method stub
		return false;
	}

}
