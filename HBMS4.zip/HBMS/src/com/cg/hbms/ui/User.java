package com.cg.hbms.ui;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.hbms.dao.MyStringDateUtil;
import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotel;
import com.cg.hbms.dto.Users;
import com.cg.hbms.dto.roomDetails;
import com.cg.hbms.exception.HotelException;
import com.cg.hbms.service.AdminService;
import com.cg.hbms.service.AdminServiceImpl;
import com.cg.hbms.service.UserService;
import com.cg.hbms.service.UserServiceImpl;

public class User {
	
	static Scanner sc = new Scanner(System.in);
	static UserService userService = null;
	static AdminService admService = null;
	public User()
	{
		try {
			userService = new UserServiceImpl();
			admService = new AdminServiceImpl();
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
		
	}
	public static void register() {
		try	{
			admService = new AdminServiceImpl();
			// TODO Auto-generated method stub
			System.out.println("Enter your Name");
			String name = sc.nextLine();
			name = validateName(name);
			System.out.println("Enter username");
			String username = sc.nextLine();
			username = validateUsername(username);
			System.out.println("Enter Password");
			String password = sc.nextLine();
			password = validatePassword(password);
			String role = "user";
			System.out.println("Enter Mobile No");
			String mobileNo = sc.nextLine();
			mobileNo = Admin.validatePhone(mobileNo);
			System.out.println("Enter Phone No");
			String phoneNo = sc.nextLine();
			phoneNo = Admin.validatePhone(phoneNo);
			System.out.println("Enter Address");
			String address = sc.nextLine();
			System.out.println("Enter Email");
			String email = sc.nextLine();
			email = Admin.validateEmail(email);
			Users user = new Users(username,password,role,name,mobileNo,phoneNo,address,email);
			int addeduser = userService.addUser(user);
			if(addeduser!=0)
			{
				System.out.println("Login");
				Main.main(null);
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		
	}
	public static String validateName(String name) {
		// TODO Auto-generated method stub
		try {
			if (userService.validate_name(name)) {
				return name;
			} 
			else {
				while (!userService.validate_name(name)) {
					System.out.println("Username already taken or max length(4) exceeded:enter again");
					name = sc.nextLine();
				}
				
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return name;
	}
	public static String validatePassword(String password) {
		// TODO Auto-generated method stub
		try {
			if (userService.validate_password(password)) {
				return password;
			} 
			else {
				while (!userService.validate_password(password)) {
					System.out.println("Password should be between 8 and 20 characters long.\r\n" + 
							"Contain at least one digit.\r\n" + 
							"Contain at least one lower case character.\r\n" + 
							"Contain at least one upper case character.\r\n" + 
							"Contain at least on special character from [ @ # $ % ! . ].");
					password = sc.nextLine();
				}
				
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return password;
	}
	public static String validateUsername(String username) {
		// TODO Auto-generated method stub
		try	{
			if (userService.validate_userName(username)) {
				return username;
			} else {
				while (!userService.validate_userName(username)) {
					System.out.println("Username already taken or max length(4) exceeded:enter again");
					username = sc.nextLine();
				}
			}
		}
		catch(HotelException e)	{
			System.out.println(e.getMessage());
		}
		return username;
	}
	
	public static void bookRoom(String userId) {
		// TODO Auto-generated method stub
		try {
			String hotel_id = getHotelNameAndCity();
			ArrayList<roomDetails> rooms = new ArrayList<roomDetails>();
			rooms = userService.searchRoom(hotel_id);
			
			while(rooms.isEmpty())
			{
				System.out.println("There are no rooms Available");
				System.out.println("Enter Another Hotel");
				hotel_id = getHotelNameAndCity();
				 rooms = new ArrayList<roomDetails>();
				rooms = userService.searchRoom(hotel_id);
			}
			System.out.println("Available Rooms: ");
			for(roomDetails room: rooms)
			{
				System.out.println(room);
			}
			System.out.println("Enter room id to Book");
			String room_id = sc.nextLine();
			System.out.println("Enter Date of check in(dd-MM-yyyy)");
			String bookedFrom = sc.nextLine();
			boolean isValidate = userService.validateDate(bookedFrom, "dd-MM-yyyy");
			while(!isValidate)
			{
				System.out.println("Invalid Check in Date");
				System.out.println("Enter Date of check in(dd-MM-yyyy)");
				 bookedFrom = sc.nextLine();
				 isValidate = userService.validateDate(bookedFrom, "dd-MM-yyyy");
			}
			LocalDate checkIn = MyStringDateUtil.fromStringToLocalDate(bookedFrom);
			System.out.println("Enter Date of Check out(dd-MM-yyyy)");
			String bookedTo = sc.nextLine();
			isValidate = userService.validateCheckOutDate(bookedTo,checkIn, "dd-MM-yyyy");
			while(!isValidate)
			{
				System.out.println("Invalid Check out Date");
				System.out.println("Enter Date of check out(dd-MM-yyyy)");
				 bookedFrom = sc.nextLine();
				 isValidate = userService.validateCheckOutDate(bookedTo,checkIn, "dd-MM-yyyy");
			}
			LocalDate checkOut = MyStringDateUtil.fromStringToLocalDate(bookedTo);
			System.out.println("Enter no. of adults");
			int adults = Integer.parseInt(sc.nextLine());
			System.out.println("Enter no. of childrens");
			int childrens = Integer.parseInt(sc.nextLine());
			BookingDetails bookRoom = new BookingDetails(hotel_id,room_id,userId,checkIn,checkOut,adults,childrens);
			double amount = 0;
			
			for(roomDetails room1 : rooms)
			{
				
				if(room1.getRoom_id().equals(room_id))
				{
					 amount = room1.getPer_night_rate();
					 
				}
			}
			Period diff = checkIn.until(checkOut);
			int noOfDays = diff.getDays();
			double finalAmount =   amount*noOfDays;
			bookRoom.setAmount(finalAmount);
			int isBooked =userService.bookRoom(bookRoom);
			if(isBooked!=0)
			{
				userService.changeAvailabilityStatus("N", room_id, hotel_id);
				System.out.println("Room booked successfully");
				System.out.println("1. Check Status\n2.Exit");
				System.out.println("Enter Choice");
				int choice =0;
				choice = Integer.parseInt(sc.nextLine());
				switch(choice)
				{
				case 1:
					checkStatus(userId);
					break;
				case 2:
					System.exit(0);
				}
			}
			
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		
	}
	public static String getHotelNameAndCity()
	{
		String hotel_id=null;
		System.out.println("Enter Hotel Name");
		String hotelName = sc.nextLine();
		System.out.println("Enter City");
		String city = sc.nextLine();
	
			ArrayList<Hotel> hotels;
			try {
				hotels = userService.getHotelIdByHotelNameAndCityName(hotelName,city);
			
			while(hotels.isEmpty())
			{
				System.out.println("Not a valid Hotel Name");
				System.out.println("Enter Hotel Name");
				 hotelName = sc.nextLine();
				System.out.println("Enter City");
				 city = sc.nextLine();
				hotels = userService.getHotelIdByHotelNameAndCityName(hotelName,city);
			}
			for(Hotel hotel : hotels)
			{
				System.out.println(hotel.getHotel_id()+"\t"+hotel.getHotel_name()+"\t"+hotel.getAddress());
			}
			System.out.println("Enter Hotel Id");
			 hotel_id = sc.nextLine();
			}
			catch (HotelException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		return hotel_id;
	}
public static void checkStatus(String userId) {
		// TODO Auto-generated method stub
		ArrayList<BookingDetails> bookings = new ArrayList<BookingDetails>();
		try {
			bookings = userService.viewBookingStatus(userId);
			for(BookingDetails booking : bookings)
			{
				System.out.println(booking);
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

public static void search() {
		boolean value=true;
		while(value) {
			System.out.println("Search By: ");
			System.out.println("1.Hotel Name\n2.City");
			int choice = Integer.parseInt(sc.nextLine());
		switch(choice)
		{
		case 1:
			System.out.println("Enter hotel Name");
			String hotelName = sc.nextLine();
			try {
				if(!searchByHotelName(hotelName))
					continue;
				else
					value=false;
				
			} catch (HotelException e) {
							System.out.println(e.getMessage());
			}
			break;
		case 2:
			System.out.println("Enter city");
			String city = sc.nextLine();
			try {
				if(!searchByCity(city))
					continue;
				else
					value=false;
				
			} catch (HotelException e1) {
				System.out.println(e1.getMessage());
				}
			break;
				
		}
		
		}
		System.out.println("Enter hotel id for Description:");
		String hotel_id = sc.nextLine();
		ArrayList<roomDetails> list2 = null;
		try {
			list2 = userService.searchRoom(hotel_id);
		} catch (HotelException e) {
			System.out.println(e.getMessage());
					}
		System.out.println(list2);
	}



public static boolean searchByCity(String city) throws HotelException{
	
	try {
	ArrayList<Hotel> listOfHotels=userService.getHotelsByCity(city);
	System.out.println("Hotel Id"+"\t"+"Hotel Name"+"\t"+"Address"+"\t"+"Phone No.");
	Iterator<Hotel> i=listOfHotels.iterator();
	Hotel h=null;
	while(i.hasNext())
	{
		h=i.next();
		System.out.println(h.getHotel_id()+"\t"+h.getHotel_name()+"\t"+h.getAddress()+"\t"+h.getPhone_no1());
	}
		
	}catch(HotelException e) {
		throw new HotelException("Invalid City or No Hotels Available ");
	}
	return true;
	
	
}
public static boolean searchByHotelName(String hotelName) throws HotelException{
	// TODO Auto-generated method stub
	try {
		ArrayList<Hotel> listOfHotels=userService.getHotelsByName(hotelName);
		System.out.println("Hotel Id"+"\t"+"Address"+"\t"+"Phone No1."+"\t"+"Phone No.2"+"\t"+"Email");
		Iterator<Hotel> i=listOfHotels.iterator();
		Hotel h=null;
		while(i.hasNext())
		{
			h=i.next();
			System.out.println(h.getHotel_id()+"\t"+h.getAddress()+"\t"+h.getPhone_no1()+"\t"+h.getPhone_no2()+"\t"+h.getEmail());
		}
		
		
		
		}catch(HotelException e) {
			throw new HotelException("Invalid hotel name or No Hotels Available ");
		}
	return true;
}
}
