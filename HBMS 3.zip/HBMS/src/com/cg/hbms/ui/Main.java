package com.cg.hbms.ui;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.hbms.dao.MyStringDateUtil;
import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotel;
import com.cg.hbms.dto.Users;
import com.cg.hbms.dto.roomDetails;
import com.cg.hbms.exception.HotelException;
import com.cg.hbms.service.AdminService;
import com.cg.hbms.service.AdminServiceImpl;
import com.cg.hbms.service.UserService;
import com.cg.hbms.service.UserServiceImpl;

public class Main {
	static UserService userService = null;
	static AdminService admService = null;
	static Scanner sc = new Scanner(System.in);
	static boolean login = false;
	static int choice;
	public static void main(String[] args) {
		try {
			userService = new UserServiceImpl();
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Welcome to Hotel Booking Management System");
		System.out.println("1.Login");
		System.out.println("2.Register");
		System.out.println("3.Exit");
		int choice=0;
		choice = Integer.parseInt(sc.nextLine());
		switch(choice)
		{
		case 1:
			login();
			break;
		case 2:
			register();
			break;
		case 3:
			System.exit(0);
		default :
			System.out.println("Wrong Choice");
		}
		
	}
	private static void login()
	{
		while (login == false) {
			try {
				
				System.out.println("Enter your userId:");
				String userId = sc.nextLine();
				System.out.println("Enter your password:");
				String password = sc.nextLine();
				String role = "";
				role = userService.login(userId, password);
				if (role.equals("")) {
					throw new HotelException("Please Enter UserName and Password Again");
				}
				System.out.println("role=" + role);
				if (role.equals("admin")) {
					adminLogin();
				} else if (role.equals("user")) {
					userLogin(userId);
				}
				else	{
					throw new HotelException("Role Configured wrong by Admin. Please Contact Admin for update");
				}
			} catch (HotelException e) {
				System.out.println(e.getMessage());
				continue;
			}
		}
	}
	private static void register() {
		try	{
			admService = new AdminServiceImpl();
			// TODO Auto-generated method stub
			System.out.println("Enter your Name");
			String name = sc.nextLine();
			name = validateName(name);
			System.out.println("Enter username");
			String username = sc.nextLine();
			username = validateUsername(username);
			System.out.println("Enter Password");
			String password = sc.nextLine();
			password = validatePassword(password);
			String role = "user";
			System.out.println("Enter Mobile No");
			String mobileNo = sc.nextLine();
			mobileNo = validatePhone(mobileNo);
			System.out.println("Enter Phone No");
			String phoneNo = sc.nextLine();
			phoneNo = validatePhone(phoneNo);
			System.out.println("Enter Address");
			String address = sc.nextLine();
			System.out.println("Enter Email");
			String email = sc.nextLine();
			email = validateEmail(email);
			Users user = new Users(username,password,role,name,mobileNo,phoneNo,address,email);
			int addeduser = userService.addUser(user);
			if(addeduser!=0)
			{
				System.out.println("Login");
				login();
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		
	}
	private static String validateName(String name) {
		// TODO Auto-generated method stub
		try {
			if (userService.validate_name(name)) {
				return name;
			} 
			else {
				while (!userService.validate_name(name)) {
					System.out.println("Username already taken or max length(4) exceeded:enter again");
					name = sc.nextLine();
				}
				
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;
	}
	private static String validatePassword(String password) {
		// TODO Auto-generated method stub
		try {
			if (userService.validate_password(password)) {
				return password;
			} 
			else {
				while (!userService.validate_password(password)) {
					System.out.println("Password should be between 8 and 20 characters long.\r\n" + 
							"Contain at least one digit.\r\n" + 
							"Contain at least one lower case character.\r\n" + 
							"Contain at least one upper case character.\r\n" + 
							"Contain at least on special character from [ @ # $ % ! . ].");
					password = sc.nextLine();
				}
				
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return password;
	}
	private static String validateUsername(String username) {
		// TODO Auto-generated method stub
		try	{
			if (userService.validate_userName(username)) {
				return username;
			} else {
				while (!userService.validate_userName(username)) {
					System.out.println("Username already taken or max length(4) exceeded:enter again");
					username = sc.nextLine();
				}
			}
		}
		catch(HotelException e)	{
			System.out.println(e.getMessage());
		}
		return username;
	}
	public static void userLogin(String userId)	{
		login = true;
		try	{
		while (login) {
			System.out.println("1.Search Hotel" + "\t" + "2. Book Room" + "\t" + "3.Check Status of Booking"+"\t"+"3.Logout");
			choice = Integer.parseInt(sc.nextLine());
			switch (choice) {
			case 1:
				search();
				break;
			case 2:
				bookRoom(userId);
				break;
			case 3:
				checkStatus(userId);
			case 4:
				login = false;
				try {
					final String os = System.getProperty("os.name");
					if (os.contains("Windows")) {
						Runtime.getRuntime().exec("cls");
					} else {
						Runtime.getRuntime().exec("clear");
					}
					break;
				} catch (Exception e) {
					throw new HotelException(e.getMessage());
				}
			default:
				System.out.println("Invalid Choice");
				break;
			}
		}
		}
		catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}
	private static void bookRoom(String userId) {
		// TODO Auto-generated method stub
		try {
			String hotel_id = getHotelNameAndCity();
			ArrayList<roomDetails> rooms = new ArrayList<roomDetails>();
			rooms = userService.searchRoom(hotel_id);
			
			while(rooms.isEmpty())
			{
				System.out.println("There are no rooms Available");
				System.out.println("Enter Another Hotel");
				hotel_id = getHotelNameAndCity();
				 rooms = new ArrayList<roomDetails>();
				rooms = userService.searchRoom(hotel_id);
			}
			System.out.println("Available Rooms: ");
			for(roomDetails room: rooms)
			{
				System.out.println(room);
			}
			System.out.println("Enter room id to Book");
			String room_id = sc.nextLine();
			System.out.println("Enter Date of check in(dd-MM-yyyy)");
			String bookedFrom = sc.nextLine();
			boolean isValidate = userService.validateDate(bookedFrom, "dd-MM-yyyy");
			while(!isValidate)
			{
				System.out.println("Invalid Check in Date");
				System.out.println("Enter Date of check in(dd-MM-yyyy)");
				 bookedFrom = sc.nextLine();
				 isValidate = userService.validateDate(bookedFrom, "dd-MM-yyyy");
			}
			LocalDate checkIn = MyStringDateUtil.fromStringToLocalDate(bookedFrom);
			System.out.println("Enter Date of Check out(dd-MM-yyyy)");
			String bookedTo = sc.nextLine();
			isValidate = userService.validateCheckOutDate(bookedTo,checkIn, "dd-MM-yyyy");
			while(!isValidate)
			{
				System.out.println("Invalid Check out Date");
				System.out.println("Enter Date of check out(dd-MM-yyyy)");
				 bookedFrom = sc.nextLine();
				 isValidate = userService.validateCheckOutDate(bookedTo,checkIn, "dd-MM-yyyy");
			}
			LocalDate checkOut = MyStringDateUtil.fromStringToLocalDate(bookedTo);
			System.out.println("Enter no. of adults");
			int adults = Integer.parseInt(sc.nextLine());
			System.out.println("Enter no. of childrens");
			int childrens = Integer.parseInt(sc.nextLine());
			BookingDetails bookRoom = new BookingDetails(hotel_id,room_id,userId,checkIn,checkOut,adults,childrens);
			double amount = 0;
			
			for(roomDetails room1 : rooms)
			{
				
				if(room1.getRoom_id().equals(room_id))
				{
					 amount = room1.getPer_night_rate();
					 
				}
			}
			Period diff = checkIn.until(checkOut);
			int noOfDays = diff.getDays();
			double finalAmount =   amount*noOfDays;
			bookRoom.setAmount(finalAmount);
			int isBooked =userService.bookRoom(bookRoom);
			if(isBooked!=0)
			{
				userService.changeAvailabilityStatus("N", room_id, hotel_id);
				System.out.println("Room booked successfully");
				System.out.println("1. Check Status\n2.Exit");
				System.out.println("Enter Choice");
				int choice =0;
				choice = Integer.parseInt(sc.nextLine());
				switch(choice)
				{
				case 1:
					checkStatus(userId);
					break;
				case 2:
					System.exit(0);
				}
			}
			
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		
	}
	private static String getHotelNameAndCity()
	{
		String hotel_id=null;
		System.out.println("Enter Hotel Name");
		String hotelName = sc.nextLine();
		System.out.println("Enter City");
		String city = sc.nextLine();
	
			ArrayList<Hotel> hotels;
			try {
				hotels = userService.getHotelIdByHotelNameAndCityName(hotelName,city);
			
			while(hotels.isEmpty())
			{
				System.out.println("Not a valid Hotel Name");
				System.out.println("Enter Hotel Name");
				 hotelName = sc.nextLine();
				System.out.println("Enter City");
				 city = sc.nextLine();
				hotels = userService.getHotelIdByHotelNameAndCityName(hotelName,city);
			}
			for(Hotel hotel : hotels)
			{
				System.out.println(hotel.getHotel_id()+"\t"+hotel.getHotel_name()+"\t"+hotel.getAddress());
			}
			System.out.println("Enter Hotel Id");
			 hotel_id = sc.nextLine();
			}
			catch (HotelException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return hotel_id;
	}
private static void checkStatus(String userId) {
		// TODO Auto-generated method stub
		ArrayList<BookingDetails> bookings = new ArrayList<BookingDetails>();
		try {
			bookings = userService.viewBookingStatus(userId);
			for(BookingDetails booking : bookings)
			{
				System.out.println(booking);
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

private static void search() {
		boolean value=true;
		while(value) {
			System.out.println("Search By: ");
			System.out.println("1.Hotel Name\n2.City");
			int choice = Integer.parseInt(sc.nextLine());
		switch(choice)
		{
		case 1:
			System.out.println("Enter hotel Name");
			String hotelName = sc.nextLine();
			try {
				if(!searchByHotelName(hotelName))
					continue;
				else
					value=false;
				
			} catch (HotelException e) {
							
			}
			break;
		case 2:
			System.out.println("Enter city");
			String city = sc.nextLine();
			try {
				if(!searchByCity(city))
					continue;
				else
					value=false;
				
			} catch (HotelException e1) {
							}
			break;
				
		}
		
		}
		System.out.println("Enter hotel id for Description:");
		String hotel_id = sc.nextLine();
		ArrayList<roomDetails> list2 = null;
		try {
			list2 = userService.searchRoom(hotel_id);
		} catch (HotelException e) {
					}
		System.out.println(list2);
	}



private static boolean searchByCity(String city) throws HotelException{
	
	try {
	ArrayList<Hotel> listOfHotels=userService.getHotelsByCity(city);
	System.out.println("Hotel Id"+"\t"+"Hotel Name"+"\t"+"Address"+"\t"+"Phone No.");
	Iterator<Hotel> i=listOfHotels.iterator();
	Hotel h=null;
	while(i.hasNext())
	{
		h=i.next();
		System.out.println(h.getHotel_id()+"\t"+h.getHotel_name()+"\t"+h.getAddress()+"\t"+h.getPhone_no1());
	}
		
	}catch(HotelException e) {
		throw new HotelException("Invalid City or No Hotels Available ");
	}
	return true;
	
	
}
private static boolean searchByHotelName(String hotelName) throws HotelException{
	// TODO Auto-generated method stub
	try {
		ArrayList<Hotel> listOfHotels=userService.getHotelsByName(hotelName);
		System.out.println("Hotel Id"+"\t"+"Address"+"\t"+"Phone No1."+"\t"+"Phone No.2"+"\t"+"Email");
		Iterator<Hotel> i=listOfHotels.iterator();
		Hotel h=null;
		while(i.hasNext())
		{
			h=i.next();
			System.out.println(h.getHotel_id()+"\t"+h.getAddress()+"\t"+h.getPhone_no1()+"\t"+h.getPhone_no2()+"\t"+h.getEmail());
		}
		
		
		
		}catch(HotelException e) {
			throw new HotelException("Invalid hotel name or No Hotels Available ");
		}
	return true;
}
/*Admin Functionalities */	
	public static void adminLogin()	{
		login = true;
		try {
			admService = new AdminServiceImpl();
			while (login) {
				System.out.println("Welcome Admin");
				System.out.println("Options Available:-");
				System.out.println("1. Add Hotel");
				System.out.println("2. Delete Hotel");
				System.out.println("3. Update Hotel");
				System.out.println("4. View All Hotels");
				System.out.println("5. View All Bookings By Hotel");
				System.out.println("6. View Bookings for a Date");
				System.out.println("7. Add Room for a hotel");
				System.out.println("8. Delete Room of a Hotel");
				System.out.println("9. Update Room Details");
				System.out.println("10. Add a new Admin");
				System.out.println("11. Logout");
				choice = Integer.parseInt(sc.nextLine());
				switch (choice) {
				case 1:
					addHotel();
					break;
				case 2:
					deleteHotel();
					break;
				case 3:
					update();
					break;
				case 4:
					fetchAll();
					break;
				case 5:
					fetchAllBookings();
					break;
				case 6:
					viewBookingByDate();
					break;
				case 7:
					addRoom();
					break;
				case 8:
					delRoom();
					break;
				case 9:
					updateRoomDetails();
					break;
				case 10:
					addAdmin();
					break;
				case 11:
					login = false;
					try {
						final String os = System.getProperty("os.name");
						if (os.contains("Windows")) {
							Runtime.getRuntime().exec("cls");
						} else {
							Runtime.getRuntime().exec("clear");
						}
						break;
					} catch (Exception e) {
						throw new HotelException(e.getMessage());
					}
				default:
					System.out.println("Invalid Choice");
					break;
				}
			}
		}
		catch(HotelException e) {
			System.out.println(e.getMessage());
		}
	}

	private static void deleteHotel() {
		// TODO Auto-generated method stub
		System.out.println("Enter the hotel id to be deleted");
		int id = Integer.parseInt(sc.nextLine());
		try {
			if (admService.hasHotelId(id)) {
				admService.deleteHotel(id);
			} else {
				throw new HotelException("Hotel Id Doesnot Exist");
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	private static void addHotel() {
		// TODO Auto-generated method stub
		System.out.println("Enter the Hotel ID");
		String id = sc.nextLine();
		System.out.println("Enter the Hotel City");
		String city = sc.nextLine();
		city = validateCityName(city);

		System.out.println("Enter the Hotel Name");
		String name = sc.nextLine();
		name = validateHotelName(name);

		System.out.println("Enter the Hotel Address");
		String address = sc.nextLine();
		System.out.println("Enter the Description");
		String description = sc.nextLine();
		System.out.println("Enter the Average rate per night");
		float avg_rate_per_night = Float.parseFloat(sc.nextLine());

		System.out.println("Enter the phone number 1");
		String phone_1 = sc.nextLine();
		phone_1 = validatePhone(phone_1);

		System.out.println("Enter the phone number 2");
		String phone_2 = sc.nextLine();
		phone_2 = validatePhone(phone_2);

		System.out.println("Enter the Rating");
		String rating = sc.nextLine();

		System.out.println("Enter the Email");
		String email = sc.nextLine();
		email = validateEmail(email);

		System.out.println("Enter the Fax");
		String fax = sc.nextLine();
		Hotel hotel = new Hotel(id, city, name, address, description, (int) avg_rate_per_night, phone_1, phone_2,
				rating, email, fax);
		try {
			admService.addHotel(hotel);
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	private static void fetchAll() {
		ArrayList<Hotel> list = null;
		try {
			list = admService.getAllHotels();
			System.out.println(list);
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}

	private static void update() {
		try {
			System.out.println("Enter hotel_id");
			String hotel_id = sc.nextLine();
			Hotel hotel1 = admService.getHotelByHotelId(hotel_id);
			if (hotel1 == null) {
				throw new HotelException("No Hotel By this Id");
			}
			System.out.println("Enter city");
			String city = sc.nextLine();
			city = validateCityName(city);
			System.out.println("Enter hotel_name");
			String hotel_name = sc.nextLine();
			hotel_name = validateHotelName(hotel_name);
			System.out.println("Enter address");
			String address = sc.nextLine();
			System.out.println("Enter description");
			String description = sc.nextLine();
			System.out.println("Enter avg_rate_per_night");
			String avg_rate_per_night = sc.nextLine();
			int avgRatePerNight = Integer.parseInt(avg_rate_per_night);
			System.out.println("Enter phone_no1");
			String phone_no1 = sc.nextLine();
			phone_no1 = validatePhone(phone_no1);
			System.out.println("Enter phone_no2");
			String phone_no2 = sc.nextLine();
			phone_no2 = validatePhone(phone_no2);
			System.out.println("Enter rating");
			String rating = sc.nextLine();
			System.out.println("email");
			String email = sc.nextLine();
			email = validateEmail(email);
			System.out.println("Enter fax");
			String fax = sc.nextLine();

			Hotel hotel = new Hotel(hotel_id, city, hotel_name, address, description, avgRatePerNight, phone_no1,
					phone_no2, rating, email, fax);
			int i = 0;
			i = admService.updateHotel(hotel);
			if (i > 0) {
				System.out.println("data Updated");
			} else {
				throw new HotelException("Data not Inserted");
			}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}

	}

	private static void fetchAllBookings() {
		try {
			System.out.println("Enter hotel_id");
			String hotel_id = sc.next();
			Hotel hotel1 = admService.getHotelByHotelId(hotel_id);
			if (hotel1 == null) {
				throw new HotelException("No Hotel By this Id");
			}
			ArrayList<BookingDetails> list = null;
			list = admService.getAllBookingsByHotel(hotel_id);
			System.out.println(list);
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}

	}

	private static void viewBookingByDate() {
		System.out.println("Enter Booking Date:");
		String str = sc.nextLine();
		LocalDate date = MyStringDateUtil.fromStringToLocalDate(str);
		ArrayList<BookingDetails> list = null;
		try {
			list = admService.viewBookingForSpecificDate(date);
			if (list == null) {
				throw new HotelException("No booking for this date");
			} else {
				for (int i = 0; i < list.size(); i++) {
					System.out.println(list.get(i));
				}
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	private static void addRoom() {
		System.out.println("Enter Hotel Id:");
		try {
			String hotel_id = sc.nextLine();
			Hotel hotel = admService.getHotelByHotelId(hotel_id);
			if (hotel == null) {
				throw new HotelException("No Hotels by this Id");
			} else {
				System.out.println("Enter Room Id:");
				String roomId = sc.nextLine();
				System.out.println("Enter Room No:");
				String roomNo = sc.nextLine();
				System.out.println("Enter Room Type:");
				String roomType = sc.nextLine();
				System.out.println("Enter Rate per Night:");
				double rate = Double.parseDouble(sc.nextLine());
				char avail = 'Y';
				roomDetails room = new roomDetails(hotel_id, roomId, roomNo, roomType, rate, avail);
				int i = admService.addRoomDetails(room);
				if (i == 1) {
					System.out.println("Details Entered Successfully");
				}
			}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}

	private static void delRoom() {
		try {
			System.out.println("Enter Room Id: ");
			String roomId = sc.nextLine();
			roomDetails room = admService.getRoomByRoomId(roomId);
			if (room == null) {
				throw new HotelException("No Room by this room Id");
			} else {
				int i = admService.deleteRoom(roomId);
				if (i > 0) {
					System.out.println("Data Deleted Successfully");
				}
			}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}

	private static void updateRoomDetails() {
		try {
			System.out.println("Enter Room Id:");
			String id = sc.nextLine();
			roomDetails room;
			room = admService.getRoomByRoomId(id);
			if (room == null) {
				throw new HotelException("No Room by this room Id");
			} else {
				System.out.println("Enter Updated Rate per Night: ");
				double rate = Double.parseDouble(sc.nextLine());
				roomDetails room1 = new roomDetails(room.getHotel_id(), room.getRoom_id(), room.getRoom_no(),
						room.getRoom_type(), rate, room.isAvailability());
				int i = admService.updateRoomDetails(room1);
				if (i > 0) {
					System.out.println("Room Details updated Successfully");
				}
			}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}
	public static void addAdmin()	{
		try	{
			System.out.println("Enter User Id");
			String uId = sc.nextLine();
			System.out.println("Enter Password");
			String pass = sc.nextLine();
			String role = "admin";
			System.out.println("Enter User Name");
			String uName = sc.nextLine();
			System.out.println("Enter Mobile Number");
			String phone = sc.nextLine();
			phone = validatePhone(phone);
			System.out.println("Enter Phone Number");
			String phone1 = sc.nextLine();
			phone1 = validateFax(phone1);
			System.out.println("Enter Address");
			String addr = sc.nextLine();
			System.out.println("Enter Email");
			String email = sc.nextLine();
			email = validateEmail(email);
			Users user = new Users(uId, pass, role, uName,phone, phone1, addr, email);
			int i = admService.addAdmin(user);
			if(i>0)	{
				System.out.println("Admin Data Entered Successfully");
			}
			else	{
				throw new HotelException("Data is not Entered");
			}
		}
		catch(HotelException e)	{
			System.out.println(e.getMessage());
		}
	}

	
	
	private static String validateEmail(String email) {

		if (admService.validateEmail(email)) {
			return email;
		} else {
			while (!admService.validateEmail(email)) {
				System.out.println("invalid email:enter again");
				email = sc.nextLine();
			}
			return email;
		}
	}

	private static String validatePhone(String ph) {

		if (admService.validatePhoneNumber(ph)) {
			return ph;
		} else {
			while (!admService.validatePhoneNumber(ph)) {
				System.out.println("invalid mobile number:enter again");
				ph = sc.nextLine();
			}
			return ph;
		}
	}

	private static String validateHotelName(String name) {

		if (admService.validateHotelName(name)) {
			return name;
		} else {
			while (!admService.validateHotelName(name)) {
				System.out.println("invalid Hotel name number:enter again");
				name = sc.nextLine();
			}
			return name;
		}
	}

	private static String validateCityName(String name) {

		if (admService.validateCityName(name)) {
			return name;
		} else {
			while (!admService.validateCityName(name)) {
				System.out.println("invalid City Name:enter again");
				name = sc.nextLine();
			}
			return name;
		}
	}
	private static String validateFax(String ph) {

		if (admService.validateFax(ph)) {
			return ph;
		} else {
			while (!admService.validateFax(ph)) {
				System.out.println("invalid phone number:enter again");
				ph = sc.nextLine();
			}
			return ph;
		}
	}
}
