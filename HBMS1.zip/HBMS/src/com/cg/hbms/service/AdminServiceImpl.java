package com.cg.hbms.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.hbms.dao.AdminDao;
import com.cg.hbms.dao.AdminDaoImpl;
import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotel;
import com.cg.hbms.dto.Users;
import com.cg.hbms.dto.roomDetails;
import com.cg.hbms.exception.HotelException;

public class AdminServiceImpl implements AdminService {
	AdminDao dao;

	public AdminServiceImpl() throws HotelException {
		dao = new AdminDaoImpl();
	}

	public ArrayList<Hotel> getAllHotels() throws HotelException {
		return dao.getAllHotels();
	}

	@Override
	public int deleteHotel(int hotel_id) throws HotelException {
		// TODO Auto-generated method stub
		return dao.deleteHotel(hotel_id);
	}

	@Override
	public int updateHotel(Hotel hotel) throws HotelException {
		return dao.updateHotel(hotel);
	}

	@Override
	public ArrayList<BookingDetails> getAllBookingsByHotel(String hotel_id) throws HotelException {
		return dao.getAllBookingsByHotel(hotel_id);
	}

	@Override
	public ArrayList<BookingDetails> viewBookingForSpecificDate(LocalDate date) throws HotelException {
		return dao.viewBookingForSpecificDate(date);
	}

	@Override
	public int addRoomDetails(roomDetails room) throws HotelException {
		return dao.addRoomDetails(room);
	}

	@Override
	public int deleteRoom(String roomId) throws HotelException {
		return dao.deleteRoom(roomId);
	}

	@Override
	public roomDetails getRoomByRoomId(String roomId) throws HotelException {
		return dao.getRoomByRoomId(roomId);
	}

	@Override
	public int updateRoomDetails(roomDetails room) throws HotelException {
		return dao.updateRoomDetails(room);
	}
	@Override
	public void addHotel(Hotel hotel) throws HotelException {
		// TODO Auto-generated method stub
		dao.addHotel(hotel);
	}
	@Override
	public Hotel getHotelByHotelId(String HotelId) throws HotelException  {
		// TODO Auto-generated method stub
		return dao.getHotelByHotelId(HotelId);
	}

	// -------Validation for Hotels--------//
	@Override
	public boolean validateHotelName(String nm) {
		boolean f=false;
		if(nm.matches("^[\\p{L} .'-]+$"))
		{
			f=true;
		}		
		return f;
	}

	// -------Validation for Hotels--------//
	@Override
	public boolean validateCityName(String city) {
		// TODO Auto-generated method stub
		boolean f=false;
		if(city.matches("^[\\p{L} .'-]+$"))
		{
			f=true;
		}	
		return f;
	}

	// -------Validation for Hotels--------//
	@Override
	public boolean validatePhoneNumber(String ph) {
		// TODO Auto-generated method stub
		boolean f=false;
		if(ph.matches("[6-9][0-9]{9}"))
		{
			f=true;
		}	
		return f;
	}

	// -------Validation for Hotels--------//
	@Override
	public boolean validateEmail(String email) {
		// TODO Auto-generated method stub
		boolean f=false;
		if(email.matches("^(.+)@(.+)$"))
		{
			f=true;
		}	
		return f;
	}

	// -------Validation for Hotels--------//
	@Override
	public boolean validateFax(String fax) {
		// TODO Auto-generated method stub
		boolean f=false;
		if(fax.matches("[+][1-9]+"))
		{
			f=true;
		}	
		return f;
	}

	@Override
	public boolean hasHotelId(int id) throws HotelException {
		System.out.println("Inside check id");
		String hid = Integer.toString(id);
		boolean f = false;
		ArrayList<Hotel> hot = dao.getAllHotels();
		// System.out.println("All hotels="+hot);
		for (Hotel h : hot) {

			if (h.getHotel_id().equals(hid)) {
				f = true;
			} else {
				f = false;
			}
		}
		return f;
	}

	@Override
	public int addAdmin(Users user) throws HotelException {
		return dao.addAdmin(user);
	}

}
