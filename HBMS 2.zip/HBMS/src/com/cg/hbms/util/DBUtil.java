package com.cg.hbms.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import com.cg.hbms.exception.HotelException;

public class DBUtil {

	static String unm;
	static String pwd;
	static String url;
	static String driver;

	public static Connection getcon() throws HotelException {
		Properties dbProps;
		Connection con = null;
		try {
			dbProps = getDBinfo();
			unm = dbProps.getProperty("dbUserName");
			pwd = dbProps.getProperty("dbPassword");
			url = dbProps.getProperty("dbUrl");
			driver = dbProps.getProperty("dbDriver");
			Class.forName(driver);
			con = DriverManager.getConnection(url, unm, pwd);
			return con;
		} catch (Exception ee) {
			ee.printStackTrace();
			// TODO Auto-generated catch block
			throw new HotelException(ee.getMessage());
		}

	}

	public static Properties getDBinfo() throws HotelException {
		try	{
			FileReader fr = new FileReader("D:\\Project\\HBMS\\src\\com\\cg\\hbms\\util\\dbinfo.properties");
			Properties myProps = new Properties();
			myProps.load(fr);
			return myProps;
			}
			catch(Exception e) {
				throw new HotelException(e.getMessage());
			}


	}

}
